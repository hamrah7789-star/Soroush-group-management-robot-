# owner_manager.py
"""
مدیریت مالک‌های گروه با فایل JSON
مسیر فایل از config گرفته میشه (سازگار با همه پلتفرم‌ها)
"""

import json
import os
import tempfile
import threading

from config import OWNERS_FILE


class OwnerManager:
    def __init__(self):
        self.file_path = OWNERS_FILE
        self._lock = threading.RLock()
        self.owners = self._load()
    
    def _load(self):
        """بارگذاری فایل مالک‌ها"""
        if not os.path.exists(self.file_path):
            return {}
        try:
            with open(self.file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
                return {}
        except json.JSONDecodeError as e:
            print(f"⚠️ JSON خراب در {self.file_path}: {e}")
            # بک‌آپ از فایل خراب
            try:
                backup = self.file_path + ".corrupted"
                os.replace(self.file_path, backup)
                print(f"📦 فایل خراب به {backup} منتقل شد")
            except:
                pass
            return {}
        except Exception as e:
            print(f"❌ خطا در خواندن {self.file_path}: {e}")
            return {}
    
    def _save(self):
        """ذخیره اتمیک در فایل (بدون خطر از دست رفتن داده)"""
        with self._lock:
            try:
                dir_name = os.path.dirname(self.file_path) or "."
                os.makedirs(dir_name, exist_ok=True)
                
                # نوشتن توی فایل موقت، بعد rename
                fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
                try:
                    with os.fdopen(fd, 'w', encoding='utf-8') as f:
                        json.dump(self.owners, f, ensure_ascii=False, indent=2)
                        f.flush()
                        os.fsync(f.fileno())
                    os.replace(tmp_path, self.file_path)
                except:
                    try:
                        os.unlink(tmp_path)
                    except:
                        pass
                    raise
            except Exception as e:
                print(f"❌ خطا در ذخیره {self.file_path}: {e}")
                raise
    
    def is_owner(self, group_id: str, user_id: str) -> bool:
        """بررسی اینکه کاربر مالک گروه هست یا نه"""
        return self.owners.get(str(group_id)) == str(user_id)
    
    def is_group_registered(self, group_id: str) -> bool:
        """بررسی اینکه گروه ثبت شده یا نه"""
        return str(group_id) in self.owners
    
    def register_group(self, group_id: str, user_id: str):
        """ثبت گروه با مالک جدید"""
        with self._lock:
            self.owners[str(group_id)] = str(user_id)
            self._save()
    
    def get_owner(self, group_id: str):
        """دریافت مالک گروه"""
        return self.owners.get(str(group_id))
    
    def remove_group(self, group_id: str):
        """حذف گروه از لیست مالک‌ها"""
        with self._lock:
            if str(group_id) in self.owners:
                del self.owners[str(group_id)]
                self._save()
                return True
        return False