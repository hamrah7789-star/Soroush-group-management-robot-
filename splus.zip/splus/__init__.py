"""
ربات مدیریت گروه سروش - نسخه 2.0.0
A powerful group management bot for Soroush messenger
"""

__version__ = "2.0.0"
__author__ = "@abc5030"
__license__ = "MIT"
__description__ = "ربات مدیریت گروه سروش با قابلیت‌های پیشرفته"

# ============================================================
# 📦 ایمپورت‌های اصلی
# ============================================================

from .config import *
from .database import Database
from .bot import SoroushBot
from .models import User, UserManager, Group, GroupManager
from .utils import *

# ============================================================
# 🎯 تنظیمات پکیج
# ============================================================

__all__ = [
    # نسخه و اطلاعات
    '__version__',
    '__author__',
    '__license__',
    '__description__',
    
    # کلاس‌های اصلی
    'Database',
    'SoroushBot',
    
    # مدل‌ها
    'User',
    'UserManager',
    'Group',
    'GroupManager',
    
    # توابع کمکی
    'to_persian_date',
    'to_persian_datetime',
    'format_number',
    'format_duration',
    'format_relative_time',
    'get_role_name',
    'get_role_emoji',
    'is_valid_phone',
    'is_valid_username',
    'random_string',
    'random_choice',
    'split_text',
    'escape_markdown',
    'get_mention',
    
    # توابع زمان
    'now',
    'now_iso',
    'to_jalali',
    'to_gregorian',
    'format_jalali_date',
    'format_jalali_datetime',
    'seconds_diff',
    'minutes_diff',
    'hours_diff',
    'days_diff',
    'is_expired',
    'is_future',
    'is_past',
    'get_start_of_day',
    'get_end_of_day',
    'get_start_of_week',
    'get_end_of_week',
    'get_start_of_month',
    'get_end_of_month',
    'get_weekday_name',
    'get_month_name',
    'is_today',
    'is_yesterday',
    'is_tomorrow',
    'is_this_week',
    'is_this_month',
    'is_this_year',
    'get_age',
    'get_time_until',
    'get_time_ago'
]

# ============================================================
# 📝 اطلاعات پکیج
# ============================================================

print(f"📦 ربات سروش نسخه {__version__}")
print(f"👤 ساخته شده توسط {__author__}")
print(f"📄 مجوز: {__license__}")
print("=" * 50)