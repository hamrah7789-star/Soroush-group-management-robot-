import sqlite3
import json
import os
import time
import threading
import queue
from datetime import datetime
from typing import Dict, List, Optional, Any
from config import BASE_PATH, DB_PATH

class Database:
    def __init__(self):
        os.makedirs(BASE_PATH, exist_ok=True)
        self.db_path = DB_PATH
        
        # 🎯 صف برای عملیات‌های نوشتن
        self.write_queue = queue.Queue()
        self.result_queues = {}
        self.counter = 0
        self._lock = threading.Lock()
        
        # 🎯 استارت ترد کارگر
        self.worker_thread = threading.Thread(target=self._worker, daemon=True)
        self.worker_thread.start()
        
        # 🎯 راه‌اندازی اولیه دیتابیس
        self._init_db()
    
    def _init_db(self):
        """راه‌اندازی اولیه دیتابیس (فقط یک بار)"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=30000")
        conn.execute("PRAGMA cache_size=-2000000")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.row_factory = sqlite3.Row
        
        self._create_tables(conn)
        self._migrate_tables(conn)
        conn.close()
    
    def _create_tables(self, conn):
        """ایجاد جدول‌ها"""
        cursor = conn.cursor()
        cursor.execute("PRAGMA foreign_keys=OFF")
        
        # ======== جدول گروه‌ها ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS groups (
                group_id TEXT PRIMARY KEY,
                group_name TEXT,
                settings TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                activated_at TIMESTAMP
            )
        """)
        
        # ======== جدول کاربران ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT,
                group_id TEXT,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                phone TEXT,
                nickname TEXT,
                origin TEXT,
                role TEXT DEFAULT 'member',
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, group_id)
            )
        """)
        
        # ======== جدول اخطارها ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS warnings (
                user_id TEXT,
                group_id TEXT,
                count INTEGER DEFAULT 0,
                last_warning TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, group_id)
            )
        """)
        
        # ======== جدول سکوت ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS mutes (
                user_id TEXT,
                group_id TEXT,
                until TIMESTAMP,
                reason TEXT,
                PRIMARY KEY (user_id, group_id)
            )
        """)
        
        # ======== جدول معافیت‌ها ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS exemptions (
                user_id TEXT,
                group_id TEXT,
                PRIMARY KEY (user_id, group_id)
            )
        """)
        
        # ======== جدول لیست سیاه ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS banned (
                user_id TEXT,
                group_id TEXT,
                reason TEXT,
                banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, group_id)
            )
        """)
        
        # ======== جدول آمار ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS stats (
                group_id TEXT PRIMARY KEY,
                data TEXT NOT NULL
            )
        """)
        
        # ======== جدول آمار روزانه ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS daily_stats (
                group_id TEXT,
                date TEXT,
                data TEXT NOT NULL,
                PRIMARY KEY (group_id, date)
            )
        """)
        
        # ======== جدول سنجاق‌ها ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pins (
                group_id TEXT,
                message_id INTEGER,
                pinned_by TEXT,
                pinned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (group_id, message_id)
            )
        """)
        
        # ======== جدول نقش‌ها ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS roles (
                group_id TEXT,
                role_name TEXT,
                permissions TEXT,
                PRIMARY KEY (group_id, role_name)
            )
        """)
        
        # ======== جدول پیام‌های کاربران ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT,
                group_id TEXT,
                message_id INTEGER,
                text TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # ======== جدول تنظیمات گروه (زبان) ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS group_settings (
                group_id TEXT PRIMARY KEY,
                lang TEXT DEFAULT 'fa',
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # ======== جدول تنظیمات کاربر (زبان) ========
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_settings (
                user_id TEXT,
                group_id TEXT,
                lang TEXT DEFAULT 'fa',
                PRIMARY KEY (user_id, group_id)
            )
        """)
        
        # ======== ایجاد ایندکس‌ها برای بهبود سرعت ========
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_messages_user_group ON user_messages(user_id, group_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_messages_group ON user_messages(group_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_messages_created ON user_messages(created_at)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_group ON users(group_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_warnings_group ON warnings(group_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_mutes_group ON mutes(group_id)")
        
        cursor.execute("PRAGMA foreign_keys=ON")
        conn.commit()
    
    def _migrate_tables(self, conn):
        """مهاجرت جدول‌ها (برای اضافه کردن ستون‌های جدید)"""
        cursor = conn.cursor()
        
        # چک کردن ستون‌های جدول users
        cursor.execute("PRAGMA table_info(users)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'nickname' not in columns:
            try:
                cursor.execute("ALTER TABLE users ADD COLUMN nickname TEXT")
            except:
                pass
        
        if 'origin' not in columns:
            try:
                cursor.execute("ALTER TABLE users ADD COLUMN origin TEXT")
            except:
                pass
        
        if 'role' not in columns:
            try:
                cursor.execute("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'member'")
            except:
                pass
        
        # چک کردن ستون activated_at در جدول groups
        cursor.execute("PRAGMA table_info(groups)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'activated_at' not in columns:
            try:
                cursor.execute("ALTER TABLE groups ADD COLUMN activated_at TIMESTAMP")
            except:
                pass
        
        conn.commit()
    
    def _worker(self):
        """ترد کارگر برای انجام عملیات‌های نوشتن"""
        conn = sqlite3.connect(self.db_path, timeout=60.0)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=60000")
        conn.execute("PRAGMA cache_size=-2000000")
        conn.row_factory = sqlite3.Row
        
        while True:
            try:
                task_id, func, args, kwargs = self.write_queue.get(timeout=1)
                
                try:
                    result = func(conn, *args, **kwargs)
                    conn.commit()
                    self._set_result(task_id, (True, result))
                except Exception as e:
                    conn.rollback()
                    self._set_result(task_id, (False, str(e)))
                finally:
                    self.write_queue.task_done()
                    
            except queue.Empty:
                continue
            except Exception as e:
                print(f"❌ Worker error: {e}")
                import traceback
                traceback.print_exc()
                continue
    
    def _set_result(self, task_id, result):
        """ذخیره نتیجه عملیات"""
        with self._lock:
            if task_id in self.result_queues:
                self.result_queues[task_id].put(result)
    
    def _execute_write(self, func, *args, **kwargs):
        """اجرای عملیات نوشتن از طریق صف"""
        with self._lock:
            task_id = self.counter
            self.counter += 1
            self.result_queues[task_id] = queue.Queue()
        
        self.write_queue.put((task_id, func, args, kwargs))
        success, result = self.result_queues[task_id].get()
        
        with self._lock:
            del self.result_queues[task_id]
        
        if not success:
            raise Exception(f"Database error: {result}")
        return result
    
    def _execute_read(self, func, *args, **kwargs):
        """اجرای عملیات خواندن (مستقیم)"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        try:
            return func(conn, *args, **kwargs)
        finally:
            conn.close()
    
    def get_connection(self):
        """دریافت اتصال جدید به دیتابیس (برای کوئری‌های مستقیم)"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        return conn
    
    # ============================================================
    # 📂 مدیریت گروه‌ها
    # ============================================================
    
    def save_group_settings(self, group_id: str, settings: Dict):
        def _save(conn, group_id, settings):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO groups (group_id, settings)
                VALUES (?, ?)
            """, (group_id, json.dumps(settings)))
        return self._execute_write(_save, group_id, settings)
    
    def load_group_settings(self, group_id: str) -> Optional[Dict]:
        def _load(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("SELECT settings FROM groups WHERE group_id = ?", (group_id,))
            result = cursor.fetchone()
            if result:
                return json.loads(result[0])
            return None
        return self._execute_read(_load, group_id)
    
    def get_all_groups(self) -> List[str]:
        def _get(conn):
            cursor = conn.cursor()
            cursor.execute("SELECT group_id FROM groups")
            return [row[0] for row in cursor.fetchall()]
        return self._execute_read(_get)
    
    def delete_group(self, group_id: str):
        def _delete(conn, group_id):
            cursor = conn.cursor()
            tables = ['groups', 'users', 'warnings', 'mutes', 'exemptions', 
                     'banned', 'stats', 'daily_stats', 'pins', 'roles', 
                     'user_messages', 'group_settings', 'user_settings']
            for table in tables:
                cursor.execute(f"DELETE FROM {table} WHERE group_id = ?", (group_id,))
        return self._execute_write(_delete, group_id)
    
    def get_group_count(self) -> int:
        def _count(conn):
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM groups")
            return cursor.fetchone()[0]
        return self._execute_read(_count)
    
    # ============================================================
    # 📅 مدیریت تاریخ فعال‌سازی گروه
    # ============================================================
    
    def set_activated_at(self, group_id: str):
        def _set(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE groups SET activated_at = CURRENT_TIMESTAMP 
                WHERE group_id = ?
            """, (group_id,))
        return self._execute_write(_set, group_id)
    
    def get_activated_at(self, group_id: str) -> Optional[str]:
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("SELECT activated_at FROM groups WHERE group_id = ?", (group_id,))
            result = cursor.fetchone()
            if result and result[0]:
                return result[0]
            return None
        return self._execute_read(_get, group_id)
    
    def get_group_created_at(self, group_id: str) -> Optional[str]:
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("SELECT created_at FROM groups WHERE group_id = ?", (group_id,))
            result = cursor.fetchone()
            if result and result[0]:
                return result[0]
            return None
        return self._execute_read(_get, group_id)
    
    # ============================================================
    # 🌍 مدیریت زبان گروه (ذخیره در دیتابیس)
    # ============================================================
    
    def get_group_lang(self, group_id: str) -> str:
        """دریافت زبان گروه (پیش‌فرض: fa)"""
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("SELECT lang FROM group_settings WHERE group_id = ?", (group_id,))
            result = cursor.fetchone()
            if result and result[0]:
                return result[0]
            return "fa"
        return self._execute_read(_get, group_id)
    
    def set_group_lang(self, group_id: str, lang: str):
        """تنظیم زبان گروه"""
        def _set(conn, group_id, lang):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO group_settings (group_id, lang)
                VALUES (?, ?)
            """, (group_id, lang))
        return self._execute_write(_set, group_id, lang)
    
    # ============================================================
    # 👤 مدیریت کاربران
    # ============================================================
    
    def save_user(self, user_id: str, group_id: str, username: str = None,
                  first_name: str = None, last_name: str = None, phone: str = None):
        def _save(conn, user_id, group_id, username, first_name, last_name, phone):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO users (user_id, group_id, username, first_name, last_name, phone)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, group_id, username, first_name, last_name, phone))
        return self._execute_write(_save, user_id, group_id, username, first_name, last_name, phone)
    
    def get_user(self, user_id: str, group_id: str) -> Optional[Dict]:
        def _get(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM users WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            row = cursor.fetchone()
            if row:
                return dict(row)
            return None
        return self._execute_read(_get, user_id, group_id)
    
    def get_all_users(self, group_id: str) -> List[Dict]:
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM users WHERE group_id = ?
            """, (group_id,))
            return [dict(row) for row in cursor.fetchall()]
        return self._execute_read(_get, group_id)
    
    def set_nickname(self, user_id: str, group_id: str, nickname: str):
        def _set(conn, user_id, group_id, nickname):
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE users SET nickname = ? WHERE user_id = ? AND group_id = ?
            """, (nickname, user_id, group_id))
        return self._execute_write(_set, user_id, group_id, nickname)
    
    def set_origin(self, user_id: str, group_id: str, origin: str):
        def _set(conn, user_id, group_id, origin):
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE users SET origin = ? WHERE user_id = ? AND group_id = ?
            """, (origin, user_id, group_id))
        return self._execute_write(_set, user_id, group_id, origin)
    
    def set_role(self, user_id: str, group_id: str, role: str):
        def _set(conn, user_id, group_id, role):
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE users SET role = ? WHERE user_id = ? AND group_id = ?
            """, (role, user_id, group_id))
        return self._execute_write(_set, user_id, group_id, role)
    
    def get_user_role(self, user_id: str, group_id: str) -> str:
        def _get(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT role FROM users WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            result = cursor.fetchone()
            return result[0] if result else "member"
        return self._execute_read(_get, user_id, group_id)
    
    def get_user_nickname(self, user_id: str, group_id: str):
        def _get(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT nickname FROM users WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            result = cursor.fetchone()
            return result[0] if result else None
        return self._execute_read(_get, user_id, group_id)
    
    def get_user_origin(self, user_id: str, group_id: str):
        def _get(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT origin FROM users WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            result = cursor.fetchone()
            return result[0] if result else None
        return self._execute_read(_get, user_id, group_id)
    
    # ============================================================
    # 📝 مدیریت پیام‌ها
    # ============================================================
    
    def add_message(self, user_id: str, group_id: str, message_id: int, text: str = ""):
        def _add(conn, user_id, group_id, message_id, text):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO user_messages (user_id, group_id, message_id, text)
                VALUES (?, ?, ?, ?)
            """, (user_id, group_id, message_id, text))
        return self._execute_write(_add, user_id, group_id, message_id, text)
    
    def add_messages_batch(self, messages: List[tuple]):
        """ذخیره دسته‌جمعی پیام‌ها"""
        def _add(conn, messages):
            cursor = conn.cursor()
            cursor.executemany("""
                INSERT INTO user_messages (user_id, group_id, message_id, text)
                VALUES (?, ?, ?, ?)
            """, messages)
        return self._execute_write(_add, messages)
    
    def get_all_messages(self, user_id: str, group_id: str) -> List[Dict]:
        def _get(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM user_messages WHERE user_id = ? AND group_id = ?
                ORDER BY created_at DESC
            """, (user_id, group_id))
            return [dict(row) for row in cursor.fetchall()]
        return self._execute_read(_get, user_id, group_id)
    
    def get_message_count(self, user_id: str, group_id: str) -> int:
        def _count(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT COUNT(*) FROM user_messages WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            return cursor.fetchone()[0]
        return self._execute_read(_count, user_id, group_id)
    
    # ============================================================
    # ⚠️ مدیریت اخطارها
    # ============================================================
    
    def get_warnings(self, user_id: str, group_id: str) -> int:
        def _get(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT count FROM warnings WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            result = cursor.fetchone()
            if result and result[0] is not None:
                return result[0]
            return 0
        return self._execute_read(_get, user_id, group_id)
    
    def add_warning(self, user_id: str, group_id: str) -> int:
        def _add(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT count FROM warnings WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            result = cursor.fetchone()
            current = result[0] if result and result[0] is not None else 0
            new_count = current + 1
            cursor.execute("""
                INSERT OR REPLACE INTO warnings (user_id, group_id, count, last_warning)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            """, (user_id, group_id, new_count))
            return new_count
        return self._execute_write(_add, user_id, group_id)
    
    def reset_warnings(self, user_id: str, group_id: str):
        def _reset(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM warnings WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
        return self._execute_write(_reset, user_id, group_id)
    
    def get_all_warnings(self, group_id: str) -> Dict:
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT user_id, count FROM warnings WHERE group_id = ?
            """, (group_id,))
            result = {}
            for row in cursor.fetchall():
                if row[1] is not None:
                    result[row[0]] = row[1]
                else:
                    result[row[0]] = 0
            return result
        return self._execute_read(_get, group_id)
    
    # ============================================================
    # 🔇 مدیریت سکوت
    # ============================================================
    
    def mute_user(self, user_id: str, group_id: str, until: str, reason: str = ""):
        def _mute(conn, user_id, group_id, until, reason):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO mutes (user_id, group_id, until, reason)
                VALUES (?, ?, ?, ?)
            """, (user_id, group_id, until, reason))
        return self._execute_write(_mute, user_id, group_id, until, reason)
    
    def unmute_user(self, user_id: str, group_id: str):
        def _unmute(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM mutes WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
        return self._execute_write(_unmute, user_id, group_id)
    
    def is_muted(self, user_id: str, group_id: str) -> tuple:
        def _check(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT until, reason FROM mutes WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            result = cursor.fetchone()
            if result:
                until = result[0]
                if until:
                    try:
                        until_time = datetime.fromisoformat(until)
                        if until_time <= datetime.now():
                            return None, None
                    except:
                        pass
                return result[0], result[1]
            return None, None
        return self._execute_read(_check, user_id, group_id)
    
    def get_muted_list(self, group_id: str) -> List[Dict]:
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT user_id, until, reason FROM mutes WHERE group_id = ?
            """, (group_id,))
            result = []
            now = datetime.now()
            for row in cursor.fetchall():
                user_id, until, reason = row
                try:
                    until_time = datetime.fromisoformat(until)
                    if until_time > now:
                        result.append({
                            'user_id': user_id,
                            'until': until,
                            'reason': reason or 'بدون دلیل'
                        })
                except:
                    pass
            return result
        return self._execute_read(_get, group_id)
    
    # ============================================================
    # 🛡️ مدیریت معافیت‌ها
    # ============================================================
    
    def add_exemption(self, user_id: str, group_id: str):
        def _add(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO exemptions (user_id, group_id)
                VALUES (?, ?)
            """, (user_id, group_id))
        return self._execute_write(_add, user_id, group_id)
    
    def remove_exemption(self, user_id: str, group_id: str):
        def _remove(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM exemptions WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
        return self._execute_write(_remove, user_id, group_id)
    
    def is_exempt(self, user_id: str, group_id: str) -> bool:
        def _check(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT 1 FROM exemptions WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            return cursor.fetchone() is not None
        return self._execute_read(_check, user_id, group_id)
    
    def get_exempt_list(self, group_id: str) -> List[str]:
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT user_id FROM exemptions WHERE group_id = ?
            """, (group_id,))
            return [row[0] for row in cursor.fetchall()]
        return self._execute_read(_get, group_id)
    
    # ============================================================
    # 🚫 مدیریت لیست سیاه
    # ============================================================
    
    def add_banned(self, user_id: str, group_id: str, reason: str = ""):
        def _add(conn, user_id, group_id, reason):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO banned (user_id, group_id, reason)
                VALUES (?, ?, ?)
            """, (user_id, group_id, reason))
        return self._execute_write(_add, user_id, group_id, reason)
    
    def remove_banned(self, user_id: str, group_id: str):
        def _remove(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM banned WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
        return self._execute_write(_remove, user_id, group_id)
    
    def is_banned(self, user_id: str, group_id: str) -> bool:
        def _check(conn, user_id, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT 1 FROM banned WHERE user_id = ? AND group_id = ?
            """, (user_id, group_id))
            return cursor.fetchone() is not None
        return self._execute_read(_check, user_id, group_id)
    
    def get_banned_list(self, group_id: str) -> List[Dict]:
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT user_id, reason, banned_at FROM banned WHERE group_id = ?
            """, (group_id,))
            return [
                {'user_id': row[0], 'reason': row[1] or 'بدون دلیل', 'banned_at': row[2]}
                for row in cursor.fetchall()
            ]
        return self._execute_read(_get, group_id)
    
    # ============================================================
    # 📊 مدیریت آمار
    # ============================================================
    
    def save_stats(self, group_id: str, data: Dict):
        def _save(conn, group_id, data):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO stats (group_id, data)
                VALUES (?, ?)
            """, (group_id, json.dumps(data)))
        return self._execute_write(_save, group_id, data)
    
    def load_stats(self, group_id: str) -> Optional[Dict]:
        def _load(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("SELECT data FROM stats WHERE group_id = ?", (group_id,))
            result = cursor.fetchone()
            if result:
                return json.loads(result[0])
            return None
        return self._execute_read(_load, group_id)
    
    def save_daily_stats(self, group_id: str, date: str, data: Dict):
        def _save(conn, group_id, date, data):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO daily_stats (group_id, date, data)
                VALUES (?, ?, ?)
            """, (group_id, date, json.dumps(data)))
        return self._execute_write(_save, group_id, date, data)
    
    def load_daily_stats(self, group_id: str, date: str) -> Optional[Dict]:
        def _load(conn, group_id, date):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT data FROM daily_stats WHERE group_id = ? AND date = ?
            """, (group_id, date))
            result = cursor.fetchone()
            if result:
                return json.loads(result[0])
            return None
        return self._execute_read(_load, group_id, date)
    
    def get_all_daily_stats(self, group_id: str, limit: int = 30) -> List[Dict]:
        def _get(conn, group_id, limit):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT date, data FROM daily_stats
                WHERE group_id = ?
                ORDER BY date DESC
                LIMIT ?
            """, (group_id, limit))
            return [
                {'date': row[0], 'data': json.loads(row[1])}
                for row in cursor.fetchall()
            ]
        return self._execute_read(_get, group_id, limit)
    
    # ============================================================
    # 📌 مدیریت سنجاق
    # ============================================================
    
    def add_pin(self, group_id: str, message_id: int, pinned_by: str):
        def _add(conn, group_id, message_id, pinned_by):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO pins (group_id, message_id, pinned_by)
                VALUES (?, ?, ?)
            """, (group_id, message_id, pinned_by))
        return self._execute_write(_add, group_id, message_id, pinned_by)
    
    def remove_pin(self, group_id: str, message_id: int):
        def _remove(conn, group_id, message_id):
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM pins WHERE group_id = ? AND message_id = ?
            """, (group_id, message_id))
        return self._execute_write(_remove, group_id, message_id)
    
    def get_pins(self, group_id: str) -> List[Dict]:
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT message_id, pinned_by, pinned_at FROM pins WHERE group_id = ?
            """, (group_id,))
            return [
                {'message_id': row[0], 'pinned_by': row[1], 'pinned_at': row[2]}
                for row in cursor.fetchall()
            ]
        return self._execute_read(_get, group_id)
    
    # ============================================================
    # 🎭 مدیریت رول‌ها
    # ============================================================
    
    def save_role(self, group_id: str, role_name: str, permissions: List[str]):
        def _save(conn, group_id, role_name, permissions):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO roles (group_id, role_name, permissions)
                VALUES (?, ?, ?)
            """, (group_id, role_name, json.dumps(permissions)))
        return self._execute_write(_save, group_id, role_name, permissions)
    
    def get_role(self, group_id: str, role_name: str) -> Optional[Dict]:
        def _get(conn, group_id, role_name):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT role_name, permissions FROM roles
                WHERE group_id = ? AND role_name = ?
            """, (group_id, role_name))
            result = cursor.fetchone()
            if result:
                return {
                    'role_name': result[0],
                    'permissions': json.loads(result[1])
                }
            return None
        return self._execute_read(_get, group_id, role_name)
    
    def get_all_roles(self, group_id: str) -> List[Dict]:
        def _get(conn, group_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT role_name, permissions FROM roles WHERE group_id = ?
            """, (group_id,))
            return [
                {'role_name': row[0], 'permissions': json.loads(row[1])}
                for row in cursor.fetchall()
            ]
        return self._execute_read(_get, group_id)
    
    def delete_role(self, group_id: str, role_name: str):
        def _delete(conn, group_id, role_name):
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM roles WHERE group_id = ? AND role_name = ?
            """, (group_id, role_name))
        return self._execute_write(_delete, group_id, role_name)
    
    # ============================================================
    # 🛠️ توابع کمکی
    # ============================================================
    
    def vacuum_db(self):
        """بهینه‌سازی دیتابیس"""
        def _vacuum(conn):
            conn.execute("VACUUM")
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        return self._execute_write(_vacuum)
    
    def backup_db(self, backup_path: str = None) -> str:
        """بک‌آپ گرفتن"""
        if backup_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"{self.db_path}.backup_{timestamp}"
        
        conn = sqlite3.connect(self.db_path)
        backup_conn = sqlite3.connect(backup_path)
        conn.backup(backup_conn)
        backup_conn.close()
        conn.close()
        
        return backup_path
    
    def check_db_status(self) -> Dict:
        """بررسی وضعیت دیتابیس"""
        def _check(conn):
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM users")
            users = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM groups")
            groups = cursor.fetchone()[0]
            cursor.execute("PRAGMA journal_mode")
            wal = cursor.fetchone()[0]
            cursor.execute("PRAGMA page_count")
            pages = cursor.fetchone()[0]
            cursor.execute("PRAGMA page_size")
            page_size = cursor.fetchone()[0]
            
            return {
                "users": users,
                "groups": groups,
                "wal_mode": wal,
                "size_mb": round((pages * page_size) / (1024 * 1024), 2)
            }
        return self._execute_read(_check)
    
    def __del__(self):
        """پاکسازی"""
        if hasattr(self, 'write_queue'):
            self.write_queue.join()