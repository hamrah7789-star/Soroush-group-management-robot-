"""
دستورات مدیریت گروه و تنظیمات پیشرفته
Group management and advanced settings commands
"""

import asyncio
import re
import random
import json
import os
import shutil
from datetime import datetime, timedelta
from spluspy import SoroushClient, events
import jdatetime

from config import MAX_GROUPS, BASE_PATH, CREATORS, HEAD_ADMIN_ID


class GroupCommands:
    """مدیریت دستورات گروه (باز/قفل/فعال/غیرفعال/reset)"""
    
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db
    
    # ============================================================
    # 👑 توابع تشخیص سازنده
    # ============================================================
    
    def is_creator(self, user_username, user_id):
        """چک کردن اینکه کاربر سازنده هست یا نه"""
        if user_username:
            for creator in CREATORS:
                if user_username.lower() == creator.lower():
                    return True
        if str(user_id) == str(HEAD_ADMIN_ID):
            return True
        return False
    
    async def handle_group_commands(self, event, chat, user_id, user_name, user_username,
                                    text, message_id, chat_id, settings, is_priv, is_creator,
                                    reply_user_id, reply_user_name, reply_msg_id, cmd_low):
        """پردازش دستورات مدیریت گروه"""
        
        cmd = text.strip()
        
        # ============================================================
        # 🏠 دستور /start (فعال‌سازی ربات - فقط مالک)
        # ============================================================
        
        if text.strip() == "/start":
            # فقط مالک یا سازنده می‌تواند فعال کند
            if not (is_priv or is_creator):
                await event.reply("❌ فقط مالک یا ادمین می‌توانند ربات را فعال کنند!")
                return True
            
            groups_count = len(self.db.get_all_groups())
            if groups_count >= MAX_GROUPS:
                await event.reply(f"❌ ربات بیش از حد مجاز ({MAX_GROUPS} گروه) فعال است!")
                return True
            
            settings["active"] = True
            if not settings.get("owner"):
                settings["owner"] = user_id
                self.db.set_role(user_id, chat_id, "owner")
            self.bot.save_settings(chat_id, settings)
            
            # ثبت تاریخ فعال‌سازی
            self.db.set_activated_at(chat_id)
            
            await event.reply("✅ ربات فعال شد!")
            return True
        
        # ============================================================
        # 🔓 دستور "فعال" (فعال‌سازی ربات - فقط مالک/ادمین)
        # ============================================================
        
        if cmd == "فعال":
            if not (is_priv or is_creator):
                await event.reply("❌ فقط مالک یا ادمین می‌توانند ربات را فعال کنند!")
                return True
            
            settings["active"] = True
            self.bot.save_settings(chat_id, settings)
            
            # ثبت تاریخ فعال‌سازی
            self.db.set_activated_at(chat_id)
            
            await event.reply("✅ **ربات فعال شد!**")
            return True
        
        # ============================================================
        # 🔒 دستور "غیر فعال" (غیرفعال‌سازی ربات - فقط مالک/ادمین)
        # ============================================================
        
        if cmd == "غیر فعال":
            if not (is_priv or is_creator):
                await event.reply("❌ فقط مالک یا ادمین می‌توانند ربات را غیرفعال کنند!")
                return True
            
            settings["active"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("❌ **ربات غیرفعال شد!**\nبرای فعال‌سازی دوباره از دستور **فعال** استفاده کنید.")
            return True
        
        # ============================================================
        # 🔓 دستور "گروه باز" (باز کردن گروه - فقط مالک/ادمین)
        # ============================================================
        
        if cmd == "گروه باز":
            if not (is_priv or is_creator):
                await event.reply("❌ فقط مالک یا ادمین می‌توانند گروه را باز کنند!")
                return True
            
            try:
                # تنظیم دسترسی‌ها با استفاده از متد موجود
                await self.bot.client.edit_permissions(
                    chat,
                    send_messages=True,
                    send_media=True,
                    send_stickers=True,
                    send_gifs=True,
                    send_games=True,
                    send_inline=True,
                    send_polls=True,
                    change_info=False,
                    invite_users=False,
                    pin_messages=False
                )
                settings["group_status"] = "باز"
                self.bot.save_settings(chat_id, settings)
                await event.reply("🔓 **گروه باز شد!**\nکاربران عادی می‌توانند پیام ارسال کنند.")
            except Exception as e:
                await event.reply(f"⚠️ خطا در باز کردن گروه: {e}")
            return True
        
        # ============================================================
        # 🔒 دستور "گروه قفل" (قفل کردن گروه - فقط مالک/ادمین)
        # ============================================================
        
        if cmd == "گروه قفل":
            if not (is_priv or is_creator):
                await event.reply("❌ فقط مالک یا ادمین می‌توانند گروه را قفل کنند!")
                return True
            
            try:
                # تنظیم دسترسی‌ها با استفاده از متد موجود
                await self.bot.client.edit_permissions(
                    chat,
                    send_messages=False,
                    send_media=False,
                    send_stickers=False,
                    send_gifs=False,
                    send_games=False,
                    send_inline=False,
                    send_polls=False,
                    change_info=False,
                    invite_users=False,
                    pin_messages=False
                )
                settings["group_status"] = "قفل"
                self.bot.save_settings(chat_id, settings)
                await event.reply("🔒 **گروه قفل شد!**\nفقط ادمین‌ها می‌توانند پیام ارسال کنند.")
            except Exception as e:
                await event.reply(f"⚠️ خطا در قفل کردن گروه: {e}")
            return True
        
        # ============================================================
        # 🔧 دستور "reset" (ریست کامل گروه - فقط مالک)
        # ============================================================
        
        if cmd_low in ["/reset", "reset"] and (user_id == settings.get("owner") or is_creator):
            try:
                # پاک کردن اطلاعات گروه از دیتابیس
                if hasattr(self.db, 'delete_group'):
                    self.db.delete_group(chat_id)
                else:
                    # روش دستی
                    with self.db.get_connection() as conn:
                        cursor = conn.cursor()
                        tables = ['groups', 'settings', 'users', 'messages', 'warnings', 
                                 'banned', 'exemptions', 'mutes', 'user_messages']
                        for table in tables:
                            try:
                                cursor.execute(f"DELETE FROM {table} WHERE group_id = ?", (chat_id,))
                            except:
                                pass
                        conn.commit()
                
                # پاک کردن فایل‌های گروه
                group_folder = os.path.join(BASE_PATH, chat_id)
                if os.path.exists(group_folder):
                    shutil.rmtree(group_folder)
                
                # ریست کردن کش‌ها
                if chat_id in self.bot.user_last_msgs:
                    del self.bot.user_last_msgs[chat_id]
                
                await event.reply("♻️ **اطلاعات گروه ریست شد!**\nبرای فعال‌سازی مجدد، دستور **/start** یا **فعال** را ارسال کنید.")
            except Exception as e:
                await event.reply(f"⚠️ خطا در ریست گروه: {e}")
            return True
        
        return False