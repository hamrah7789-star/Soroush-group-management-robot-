import asyncio
import re
import random
import json
import os
import shutil
from datetime import datetime, timedelta
import jdatetime
import sqlite3
from config import BASE_PATH


class BotHandlers:
    def __init__(self, bot):
        self.bot = bot
        self.db = bot.db

    async def handle_admin_commands(self, event, chat, user_id, user_name, user_username,
                                    text, message_id, chat_id, settings, is_priv, is_creator,
                                    reply_user_id, reply_user_name, reply_msg_id, cmd_low):
        """پردازش دستورات مدیریتی"""

        cmd = text.strip()
        filters = settings.get("filters", {})

        # ======== دستورات فیلتر ========
        if cmd == "لینک باز":
            filters["link"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر لینک غیرفعال شد")
            return True
        if cmd == "لینک قفل":
            filters["link"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر لینک فعال شد")
            return True

        if cmd == "ایدی باز":
            filters["at"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر ایدی غیرفعال شد")
            return True
        if cmd == "ایدی قفل":
            filters["at"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر ایدی فعال شد")
            return True

        if cmd == "فحش باز":
            filters["badword"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر فحش غیرفعال شد")
            return True
        if cmd == "فحش قفل":
            filters["badword"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر فحش فعال شد")
            return True

        if cmd == "فوروارد باز":
            filters["forward"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر فوروارد غیرفعال شد")
            return True
        if cmd == "فوروارد قفل":
            filters["forward"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر فوروارد فعال شد")
            return True

        if cmd == "کدهنگی باز":
            filters["hang"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر کدهنگی غیرفعال شد")
            return True
        if cmd == "کدهنگی قفل":
            filters["hang"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر کدهنگی فعال شد")
            return True

        if cmd == "اسپم باز":
            filters["spam"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر اسپم غیرفعال شد")
            return True
        if cmd == "اسپم قفل":
            filters["spam"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر اسپم فعال شد")
            return True

        if cmd == "سیاسی باز":
            filters["political"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر سیاسی غیرفعال شد")
            return True
        if cmd == "سیاسی قفل":
            filters["political"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر سیاسی فعال شد")
            return True

        if cmd == "تبلیغ باز":
            filters["advertisement"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر تبلیغ غیرفعال شد")
            return True
        if cmd == "تبلیغ قفل":
            filters["advertisement"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚠️ فیلتر تبلیغ فعال شد")
            return True

        # ======== دستورات بن ========
        if cmd == "بن فعال":
            settings["auto_ban"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("✅ بن خودکار فعال شد")
            return True
        if cmd == "بن غیر فعال":
            settings["auto_ban"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("✅ بن خودکار غیرفعال شد")
            return True

        # ======== تغییر حداکثر اخطار ========
        if cmd_low.startswith("اخطار "):
            try:
                num = int(cmd_low.replace("اخطار ", "", 1).strip())
                if 1 <= num <= 30:
                    settings["max_warnings"] = num
                    self.bot.save_settings(chat_id, settings)
                    await event.reply(f"✅ حداکثر اخطار به {num} تغییر کرد")
                else:
                    await event.reply("⚠️ عدد باید بین ۱ تا ۳۰ باشد")
            except:
                await event.reply("⚠️ فرمت درست: اخطار عدد (مثلاً اخطار 7)")
            return True

        # ======== حذف پیام ========
        if cmd_low.startswith("حذف پیام "):
            try:
                count = int(cmd_low.replace("حذف پیام ", "", 1).strip())
                if count > 500:
                    await event.reply("⚠️ حداکثر ۵۰۰ پیام می‌تونی پاک کنی!")
                    return True
                if count < 1:
                    await event.reply("⚠️ حداقل ۱ پیام!")
                    return True

                deleted = 0
                messages = await self.bot.client.get_messages(chat, limit=count)
                for msg in messages:
                    await self.bot.client.delete_messages(chat, [msg.id])
                    deleted += 1
                    await asyncio.sleep(0.1)

                await event.reply(f"🗑️ {deleted} پیام حذف شد!")

            except Exception as e:
                await event.reply(f"⚠️ خطا: {e}")
            return True

        # ======== لیست‌ها ========
        if cmd == "لیست ادمین":
            owner = settings.get("owner", "نامشخص")
            admins = settings.get("admins", [])
            msg = f"👑 **مالک:** {self.bot.get_user_display(owner, chat_id)}\n"
            if admins:
                msg += "👥 **ادمین‌ها:**\n"
                for admin_id in admins:
                    msg += f"   {self.bot.get_user_display(admin_id, chat_id)}\n"
            else:
                msg += "هیچ ادمین اضافی وجود ندارد"
            await event.reply(msg)
            return True

        if cmd == "لیست معاف":
            exempt_list = self.db.get_exempt_list(chat_id)
            if not exempt_list:
                await event.reply("❌ هیچ کاربری معاف نیست")
                return True
            msg = "📋 **کاربران معاف:**\n"
            for uid in exempt_list:
                msg += f"   {self.bot.get_user_display(uid, chat_id)}\n"
            await event.reply(msg)
            return True

        if cmd == "لیست سیاه":
            banned_list = self.db.get_banned_list(chat_id)
            if not banned_list:
                await event.reply("❌ هیچ کاربری در لیست سیاه نیست")
                return True
            msg = "🚫 **لیست سیاه:**\n━━━━━━━━━━━━━━━━━\n"
            for item in banned_list:
                msg += f"   {self.bot.get_user_display(item['user_id'], chat_id)}\n"
                msg += f"   📝 دلیل: {item['reason'] or 'ندارد'}\n\n"
            await event.reply(msg)
            return True

        if cmd == "لیست قفل":
            status_text = {"badword": "فحش", "link": "لینک", "at": "ایدی", "hang": "کدهنگی", "spam": "اسپم",
                           "political": "سیاسی", "advertisement": "تبلیغ", "forward": "فوروارد"}
            lines = [f"{status_text.get(k, k)}: {'🔒 فعال' if v else '🔓 غیرفعال'}" for k, v in filters.items()]
            lines.append(f"بن خودکار: {'🔒 فعال' if settings.get('auto_ban', True) else '🔓 غیرفعال'}")
            lines.append(f"حداکثر اخطار: {settings.get('max_warnings', 5)}")
            await event.reply("📋 وضعیت فیلترها:\n" + "\n".join(lines))
            return True

        # ======== دستورات با ریپلای ========
        if cmd == "بن" and reply_user_id:
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ مالک رو نمی‌تونی بن کنی!")
                return True
            if reply_user_id == self.bot.bot_id:
                await event.reply("❌ خودم رو نمی‌تونم بن کنم!")
                return True
            try:
                await self.bot.client.kick_participant(chat, int(reply_user_id))
                self.db.add_banned(reply_user_id, chat_id, "بن توسط ادمین")
                self.db.reset_warnings(reply_user_id, chat_id)
                await event.reply(f"🚫 {reply_user_name} بن شد!")
            except:
                await event.reply(f"⚠️ نتونستم {reply_user_name} رو بن کنم!")
            return True

        if cmd == "تغییر مالک" and reply_user_id and user_id == settings.get("owner"):
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ این کاربر قبلاً مالک است!")
            else:
                settings["owner"] = reply_user_id
                self.db.set_role(reply_user_id, chat_id, "owner")
                self.bot.save_settings(chat_id, settings)
                await event.reply(f"✅ {reply_user_name} به عنوان مالک جدید انتخاب شد!")
            return True

        if cmd == "اخطار" and reply_user_id:
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ مالک رو نمی‌تونی اخطار بدی!")
                return True
            current = self.db.add_warning(reply_user_id, chat_id)
            max_w = settings.get("max_warnings", 5)

            if current >= max_w and settings.get("auto_ban", True):
                try:
                    await self.bot.client.kick_participant(chat, int(reply_user_id))
                    self.db.add_banned(reply_user_id, chat_id, "اخطار بیش از حد")
                    stats = self.db.load_stats(chat_id) or {}
                    stats["banned"] = stats.get("banned", 0) + 1
                    self.db.save_stats(chat_id, stats)
                    self.db.reset_warnings(reply_user_id, chat_id)
                    await event.reply(f"🚫 {reply_user_name} بن دائمی شد! [{max_w}/{current}]")
                except:
                    await event.reply(f"⚠️ نتونستم {reply_user_name} رو بن کنم!")
            else:
                await event.reply(f"⚠️ اخطار {current}/{max_w} به {reply_user_name}")
            return True

        if cmd == "ادمین" and reply_user_id and (user_id == settings.get("owner") or is_creator):
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ مالک خودش ادمین هست!")
                return True
            admins = settings.setdefault("admins", [])
            if reply_user_id not in admins:
                admins.append(reply_user_id)
                self.db.set_role(reply_user_id, chat_id, "admin")
                self.bot.save_settings(chat_id, settings)
                await event.reply(f"✅ {reply_user_name} ادمین شد!")
            else:
                await event.reply(f"{reply_user_name} قبلاً ادمین هست!")
            return True

        if cmd == "حذف ادمین" and reply_user_id and (user_id == settings.get("owner") or is_creator):
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ مالک رو نمی‌تونی حذف کنی!")
                return True
            admins = settings.get("admins", [])
            if reply_user_id in admins:
                admins.remove(reply_user_id)
                self.db.set_role(reply_user_id, chat_id, "member")
                self.bot.save_settings(chat_id, settings)
                await event.reply(f"✅ {reply_user_name} از ادمینی حذف شد!")
            else:
                await event.reply(f"{reply_user_name} ادمین نبود!")
            return True

        if cmd == "معاف" and reply_user_id:
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ مالک معاف نمی‌شود!")
                return True
            self.db.add_exemption(reply_user_id, chat_id)
            await event.reply(f"✅ {reply_user_name} معاف شد!")
            return True

        if cmd == "حذف معاف" and reply_user_id:
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ مالک معاف نیست!")
                return True
            self.db.remove_exemption(reply_user_id, chat_id)
            await event.reply(f"✅ {reply_user_name} از معافیت حذف شد!")
            return True

        if cmd == "حذف بن" and reply_user_id:
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ مالک که بن نیست!")
                return True
            self.db.remove_banned(reply_user_id, chat_id)
            await event.reply(f"✅ {reply_user_name} از بن خارج شد!")
            return True

        if cmd == "ریست اخطار" and reply_user_id:
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ مالک اخطار نداره!")
                return True
            self.db.reset_warnings(reply_user_id, chat_id)
            await event.reply(f"✅ اخطارهای {reply_user_name} ریست شد!")
            return True

        # ============================================================
        # 🔇 دستور سکوت (با چک دسترسی کامل)
        # ============================================================

        if cmd_low.startswith("سکوت") and reply_user_id:
            # ۱. چک کردن اینکه خودش رو سکوت نکنه
            if reply_user_id == user_id:
                await event.reply("❌ نمی‌تونی خودت رو سکوت کنی!")
                return True
            
            # ۲. چک کردن اینکه ربات رو سکوت نکنه
            if reply_user_id == self.bot.bot_id:
                await event.reply("❌ ایشون من هستم! 😤")
                return True
            
            # ۳. چک کردن اینکه مالک رو سکوت نکنه
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ ایشون مالک هستن! 🙅‍♂️")
                return True
            
            # ۴. چک کردن اینکه ادمین دیگه رو سکوت نکنه (فقط مالک یا سازنده)
            if reply_user_id in settings.get("admins", []):
                if user_id != settings.get("owner") and not is_creator:
                    await event.reply("❌ ایشون ادمین هستن! فقط مالک یا سازنده می‌تونن ادمین رو سکوت کنن.")
                    return True
            
            # ۵. چک کردن اینکه کاربر بن نباشه
            if self.db.is_banned(reply_user_id, chat_id):
                await event.reply("❌ این کاربر بن هست! نمی‌تونی سکوتش کنی.")
                return True
            
            # ادامه کد سکوت
            parts = text.strip().split(maxsplit=2)
            if len(parts) >= 2:
                try:
                    duration = int(parts[1])
                    if duration < 1:
                        await event.reply("⚠️ مدت زمان باید بیشتر از ۰ باشد!")
                        return True
                    
                    reason = parts[2] if len(parts) >= 3 else "بدون دلیل"
                    
                    until = (datetime.now() + timedelta(seconds=duration)).isoformat()
                    self.db.mute_user(reply_user_id, chat_id, until, reason)
                    await event.reply(f"🔇 {reply_user_name} به مدت {duration} ثانیه سکوت شد!\n📝 دلیل: {reason}")
                except ValueError:
                    await event.reply("⚠️ مدت زمان را به ثانیه وارد کنید!\nمثال: سکوت 60 اسپم")
            else:
                await event.reply("⚠️ فرمت درست:\nسکوت مدت زمان دلیل\nمثال: سکوت 60 اسپم")
            return True

        # ============================================================
        # 🔊 برداشتن سکوت
        # ============================================================

        if cmd == "برداشتن سکوت" and reply_user_id:
            if reply_user_id == self.bot.bot_id:
                await event.reply("❌ من که سکوت نیستم! 😂")
                return True
            
            if reply_user_id == settings.get("owner"):
                await event.reply("❌ مالک که سکوت نیست!")
                return True
            
            self.db.unmute_user(reply_user_id, chat_id)
            await event.reply(f"🔊 سکوت {reply_user_name} برداشته شد!")
            return True

        # ======== لیست سکوت (با تاریخ شمسی) ========
        if cmd == "لیست سکوت":
            muted_list = self.db.get_muted_list(chat_id)
            if not muted_list:
                await event.reply("❌ هیچ کاربری سکوت نیست!")
                return True
            msg = "🔇 **لیست کاربران سکوت شده:**\n━━━━━━━━━━━━━━━━━\n"
            for item in muted_list:
                user = self.db.get_user(item['user_id'], chat_id)
                if user:
                    name = user.get('first_name') or item['user_id']
                else:
                    name = item['user_id']
                
                try:
                    dt = datetime.fromisoformat(item['until'])
                    jd = jdatetime.datetime.fromgregorian(datetime=dt)
                    until_shamsi = jd.strftime("%Y/%m/%d %H:%M")
                except:
                    until_shamsi = item['until']
                
                msg += f"• {name}\n  ⏱️ تا: {until_shamsi}\n  📝 دلیل: {item['reason'] or 'ندارد'}\n\n"
            await event.reply(msg)
            return True

        # ============================================================
        # 🔄 دستورات ریست لیست‌های جداگانه
        # ============================================================

        if cmd == "ریست لیست ادمین" and (user_id == settings.get("owner") or is_creator):
            settings["admins"] = []
            self.bot.save_settings(chat_id, settings)
            await event.reply("✅ **لیست ادمین‌ها ریست شد!**")
            return True

        if cmd == "ریست لیست معاف" and (user_id == settings.get("owner") or is_creator):
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM exemptions WHERE group_id = ?", (chat_id,))
                conn.commit()
            await event.reply("✅ **لیست معاف‌ها ریست شد!**")
            return True

        if cmd == "ریست لیست سیاه" and (user_id == settings.get("owner") or is_creator):
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM banned WHERE group_id = ?", (chat_id,))
                conn.commit()
            await event.reply("✅ **لیست سیاه ریست شد!**")
            return True

        if cmd == "ریست لیست اخطار" and (user_id == settings.get("owner") or is_creator):
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM warnings WHERE group_id = ?", (chat_id,))
                conn.commit()
            await event.reply("✅ **لیست اخطارها ریست شد!**")
            return True

        if cmd == "ریست لیست سکوت" and (user_id == settings.get("owner") or is_creator):
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM mutes WHERE group_id = ?", (chat_id,))
                conn.commit()
            await event.reply("✅ **لیست سکوت ریست شد!**")
            return True

        if cmd == "ریست لیست" and (user_id == settings.get("owner") or is_creator):
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM banned WHERE group_id = ?", (chat_id,))
                cursor.execute("DELETE FROM warnings WHERE group_id = ?", (chat_id,))
                cursor.execute("DELETE FROM exemptions WHERE group_id = ?", (chat_id,))
                cursor.execute("DELETE FROM mutes WHERE group_id = ?", (chat_id,))
                conn.commit()
            await event.reply("♻️ **همه لیست‌ها ریست شدند!**")
            return True

        # ============================================================
        # 🎯 ثبت جنسیت (دو حالت)
        # ============================================================

        if cmd_low == "دخترم" and not reply_user_id:
            self.bot.user_data.set_gender(user_id, chat_id, "female")
            await event.reply(f"✅ جنسیت شما به **دختر** ثبت شد!")
            return True

        if cmd_low == "پسرم" and not reply_user_id:
            self.bot.user_data.set_gender(user_id, chat_id, "male")
            await event.reply(f"✅ جنسیت شما به **پسر** ثبت شد!")
            return True

        if cmd_low == "دختر" and reply_user_id and is_priv:
            self.bot.user_data.set_gender(reply_user_id, chat_id, "female")
            await event.reply(f"✅ جنسیت {reply_user_name} به **دختر** ثبت شد!")
            return True

        if cmd_low == "پسر" and reply_user_id and is_priv:
            self.bot.user_data.set_gender(reply_user_id, chat_id, "male")
            await event.reply(f"✅ جنسیت {reply_user_name} به **پسر** ثبت شد!")
            return True

        if cmd_low.startswith("ثبت لقب") and reply_user_id:
            nickname = text.strip()[8:].strip()
            if nickname:
                self.bot.user_data.set_nickname(reply_user_id, chat_id, nickname)
                await event.reply(f"✅ لقب '{nickname}' برای {reply_user_name} ثبت شد!")
            else:
                await event.reply("⚠️ بعد از 'ثبت لقب' یک کلمه وارد کنید!")
            return True

        if cmd_low.startswith("ثبت اصل") and reply_user_id:
            origin = text.strip()[7:].strip()
            if origin:
                self.bot.user_data.set_origin(reply_user_id, chat_id, origin)
                await event.reply(f"✅ اصل '{origin}' برای {reply_user_name} ثبت شد!")
            else:
                await event.reply("⚠️ بعد از 'ثبت اصل' یک کلمه وارد کنید!")
            return True

        if cmd.startswith("فیلتر "):
            word = cmd[6:].strip()
            if not word:
                await event.reply("بعد از 'فیلتر ' یک کلمه بنویسید")
                return True
            custom = settings.setdefault("custom_badwords", [])
            if word not in custom:
                custom.append(word)
                self.bot.save_settings(chat_id, settings)
                await event.reply(f"✅ '{word}' به لیست فحش اضافه شد")
            else:
                await event.reply(f"'{word}' قبلاً در لیست هست")
            return True

        if cmd.startswith("حذف فیلتر "):
            word = cmd[11:].strip()
            if not word:
                await event.reply("بعد از 'حذف فیلتر ' یک کلمه بنویسید")
                return True
            custom = settings.get("custom_badwords", [])
            if word in custom:
                custom.remove(word)
                self.bot.save_settings(chat_id, settings)
                await event.reply(f"✅ '{word}' از لیست فحش حذف شد")
            else:
                await event.reply(f"'{word}' در لیست نبود")
            return True

        if cmd == "لیست فحش":
            custom = settings.get("custom_badwords", [])
            if custom:
                await event.reply("📋 لیست فحش سفارشی:\n" + "\n".join(custom))
            else:
                from bot import BAD_WORDS
                await event.reply("از لیست پیش‌فرض استفاده می‌شود:\n" + "\n".join(BAD_WORDS))
            return True

        # ============================================================
        # 📊 دستورات آمار (با UserDataManager و جنسیت)
        # ============================================================

        if cmd == "آمارش" and reply_user_id:
            target_id = reply_user_id
            await self._send_user_stats(event, chat, target_id, chat_id)
            return True

        if cmd == "آمار من":
            target_id = user_id
            await self._send_user_stats(event, chat, target_id, chat_id)
            return True

        if cmd == "آمار گروه" and (user_id == settings.get("owner") or is_creator):
            stats = self.db.load_stats(chat_id) or {}
            speaker_name = settings.get("speaker", "با ادب")
            speaker_status = "روشن ✅" if settings.get("speaker_enabled", True) else "خاموش ❌"
            mode_text = "پر حرفی" if settings.get("mode") == "talkative" else "کم حرفی"
            total_users = len(self.db.get_all_users(chat_id))
            group_status = settings.get("group_status", "باز")
            
            # دریافت تاریخ فعال‌سازی
            activated_at = self.db.get_activated_at(chat_id)
            
            # تبدیل تاریخ به شمسی
            activation_date = "نامشخص"
            if activated_at:
                try:
                    dt = datetime.fromisoformat(activated_at)
                    jd = jdatetime.datetime.fromgregorian(datetime=dt)
                    activation_date = jd.strftime("%Y/%m/%d - %H:%M")
                except:
                    activation_date = activated_at
            
            if group_status == "باز":
                status_icon = "🔓"
                status_text = "باز (همه می‌توانند پیام بفرستند)"
            else:
                status_icon = "🔒"
                status_text = "قفل (فقط ادمین‌ها می‌توانند پیام بفرستند)"

            msg = f"📊 **آمار گروه**\n━━━━━━━━━━━━━━━━━\n"
            msg += f"📛 نام گروه: {chat.title or 'بدون نام'}\n"
            msg += f"🆔 آیدی گروه: {chat_id}\n"
            msg += f"👥 کاربران فعال: {total_users}\n"
            msg += f"🚫 بن شده‌ها: {stats.get('banned', 0)}\n"
            msg += f"🗑️ پیام حذف شده: {stats.get('deleted', 0)}\n"
            msg += f"⚠️ کل اخطارها: {stats.get('warnings', 0)}\n"
            msg += f"💬 کل پیام‌ها: {stats.get('total_messages', 0)}\n"
            msg += f"🗓️ تاریخ شروع فعالیت: {activation_date}\n"
            msg += f"━━━━━━━━━━━━━━━━━\n"
            msg += f"🎭 سخنگو: {speaker_name}\n"
            msg += f"🔊 وضعیت: {speaker_status}\n"
            msg += f"📢 حالت: {mode_text}\n"
            msg += f"{status_icon} وضعیت گروه: {status_text}"
            
            await event.reply(msg)
            return True

        if cmd == "آمار":
            stats = self.db.load_stats(chat_id) or {}
            msg = f"📊 **آمار گروه:**\n━━━━━━━━━━━━━━━━━\n"
            msg += f"🚫 کاربران بن شده: {stats.get('banned', 0)}\n"
            msg += f"🗑️ پیام‌های حذف شده: {stats.get('deleted', 0)}\n"
            msg += f"⚠️ تعداد کل اخطارها: {stats.get('warnings', 0)}\n"
            await event.reply(msg)
            return True

        if cmd == "ریست آمار" and (user_id == settings.get("owner") or is_creator):
            self.db.save_stats(chat_id, {"banned": 0, "deleted": 0, "text_deleted": 0, "warnings": 0,
                                         "total_messages": 0})
            await event.reply("♻️ آمار گروه از صفر شروع شد")
            return True

        # ============================================================
        # 🎭 دستورات سخنگو
        # ============================================================

        if cmd_low in ["حالت کم حرفی", "/حالت کم حرفی"] and (user_id == settings.get("owner") or is_creator):
            settings["mode"] = "quiet"
            self.bot.save_settings(chat_id, settings)
            await event.reply("🤫 حالت کم‌حرفی فعال شد!")
            return True

        if cmd_low in ["حالت پر حرفی", "/حالت پر حرفی"] and (user_id == settings.get("owner") or is_creator):
            settings["mode"] = "talkative"
            self.bot.save_settings(chat_id, settings)
            await event.reply("🗣️ حالت پر‌حرفی فعال شد!")
            return True

        if cmd_low in ["تغییر سخنگو", "/تغییر سخنگو"]:
            await event.reply(
                "🎭 **انتخاب سخنگو:**\n━━━━━━━━━━━━━━━━━\n🌸 /سخنگو انیمه\n😈 /سخنگو بی ادب\n🤵 /سخنگو با ادب\n💻 /سخنگو برنامه نویسی\n🌑 /سخنگو خفن\n━━━━━━━━━━━━━━━━━\n⚡ /سخنگو روشن\n🔕 /سخنگو خاموش")
            return True

        speaker_map = {
            "سخنگو انیمه": "anime", "/سخنگو انیمه": "anime",
            "سخنگو بی ادب": "biadab", "/سخنگو بی ادب": "biadab",
            "سخنگو با ادب": "baadab", "/سخنگو با ادب": "baadab",
            "سخنگو برنامه نویسی": "programmer", "/سخنگو برنامه نویسی": "programmer",
            "سخنگو خفن": "khoof", "/سخنگو خفن": "khoof"
        }

        if cmd_low in speaker_map:
            settings["speaker"] = speaker_map[cmd_low]
            self.bot.save_settings(chat_id, settings)
            await event.reply(f"✅ سخنگو به {cmd_low.replace('/', '')} تغییر کرد!")
            return True

        if cmd_low in ["سخنگو روشن", "/سخنگو روشن"]:
            settings["speaker_enabled"] = True
            self.bot.save_settings(chat_id, settings)
            await event.reply("⚡ سخنگو روشن شد!")
            return True

        if cmd_low in ["سخنگو خاموش", "/سخنگو خاموش"]:
            settings["speaker_enabled"] = False
            self.bot.save_settings(chat_id, settings)
            await event.reply("🔕 سخنگو خاموش شد!")
            return True

        if cmd_low in ["/reset", "reset"] and (user_id == settings.get("owner") or is_creator):
            try:
                shutil.rmtree(os.path.join(BASE_PATH, chat_id))
                await event.reply("♻️ اطلاعات گروه ریست شد. دوباره /start بزنید")
            except:
                await event.reply("خطا در ریست گروه")
            return True

        return False

    # ============================================================
    # 📊 تابع کمکی برای آمار کاربر (با UserDataManager و جنسیت)
    # ============================================================

    async def _send_user_stats(self, event, chat, target_id, chat_id):
        """ارسال آمار کاربر با لقب، اصل و جنسیت از فایل JSON"""

        conn = sqlite3.connect(self.db.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        try:
            # تعداد پیام‌ها
            cursor.execute("""
                SELECT COUNT(*) FROM user_messages 
                WHERE user_id = ? AND group_id = ?
            """, (target_id, chat_id))
            count = cursor.fetchone()[0]

            # تعداد اخطارها
            cursor.execute("""
                SELECT count FROM warnings 
                WHERE user_id = ? AND group_id = ?
            """, (target_id, chat_id))
            warn_row = cursor.fetchone()
            warns = warn_row[0] if warn_row else 0

            # اولین پیام
            cursor.execute("""
                SELECT created_at FROM user_messages 
                WHERE user_id = ? AND group_id = ? 
                ORDER BY created_at ASC LIMIT 1
            """, (target_id, chat_id))
            first_msg_row = cursor.fetchone()
            first_msg = None
            if first_msg_row:
                try:
                    dt = datetime.fromisoformat(first_msg_row[0])
                    jd = jdatetime.datetime.fromgregorian(datetime=dt)
                    first_msg = jd.strftime("%Y/%m/%d %H:%M:%S")
                except:
                    first_msg = first_msg_row[0]

        except Exception as e:
            print(f"❌ Error in _send_user_stats: {e}")
            count = 0
            warns = 0
            first_msg = None
        finally:
            conn.close()

        # دریافت لقب، اصل و جنسیت از UserDataManager
        nickname = self.bot.user_data.get_nickname(target_id, chat_id)
        origin = self.bot.user_data.get_origin(target_id, chat_id)
        gender = self.bot.user_data.get_gender(target_id, chat_id)

        # تبدیل جنسیت به فارسی
        if gender == "male":
            gender_display = "👦 پسر"
        elif gender == "female":
            gender_display = "👧 دختر"
        else:
            gender_display = "❌ ثبت نشده"

        # ساخت پیام
        msg = f"📊 **آمار {self.bot.get_user_display(target_id, chat_id)}**\n"
        msg += "━━━━━━━━━━━━━━━━━\n"
        msg += f"🆔 آیدی: {target_id}\n"
        msg += f"👤 جنسیت: {gender_display}\n"

        if nickname:
            msg += f"🏷️ لقب: {nickname}\n"

        if origin:
            msg += f"📌 اصل: {origin}\n"

        msg += f"📝 تعداد پیام‌ها: {count}\n"
        msg += f"⚠️ تعداد اخطارها: {warns}\n"

        if first_msg:
            msg += f"📅 اولین پیام: {first_msg}"

        await event.reply(msg)