# rules_manager.py
"""
مدیریت قوانین گروه
مسیر فایل از config گرفته میشه (سازگار با همه پلتفرم‌ها)
"""

import json
import os
import tempfile
import threading
from datetime import datetime

from config import RULES_FILE


class RulesManager:
    """مدیریت قوانین گروه"""
    
    def __init__(self):
        self.file_path = RULES_FILE
        self._lock = threading.RLock()
        self.rules = self._load()
    
    def _load(self) -> dict:
        """بارگذاری قوانین از فایل"""
        if not os.path.exists(self.file_path):
            return {}
        try:
            with open(self.file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
                return {}
        except json.JSONDecodeError as e:
            print(f"⚠️ JSON خراب در {self.file_path}: {e}")
            try:
                backup = self.file_path + ".corrupted"
                os.replace(self.file_path, backup)
                print(f"📦 فایل خراب به {backup} منتقل شد")
            except:
                pass
            return {}
        except Exception as e:
            print(f"❌ خطا در خواندن {self.file_path}: {e}")
            return {}
    
    def _save(self):
        """ذخیره اتمیک در فایل"""
        with self._lock:
            try:
                dir_name = os.path.dirname(self.file_path) or "."
                os.makedirs(dir_name, exist_ok=True)
                
                fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
                try:
                    with os.fdopen(fd, 'w', encoding='utf-8') as f:
                        json.dump(self.rules, f, ensure_ascii=False, indent=2)
                        f.flush()
                        os.fsync(f.fileno())
                    os.replace(tmp_path, self.file_path)
                except:
                    try:
                        os.unlink(tmp_path)
                    except:
                        pass
                    raise
            except Exception as e:
                print(f"❌ خطا در ذخیره {self.file_path}: {e}")
                raise
    
    # ============================================================
    # 📜 دستورات اصلی
    # ============================================================
    
    def set_rule(self, group_id: str, rule_text: str, set_by: str) -> bool:
        """ثبت قانون برای گروه"""
        with self._lock:
            self.rules[str(group_id)] = {
                "text": rule_text,
                "set_by": str(set_by),
                "set_at": datetime.now().isoformat()
            }
            self._save()
            return True
    
    def get_rule(self, group_id: str):
        """دریافت قانون گروه"""
        return self.rules.get(str(group_id))
    
    def delete_rule(self, group_id: str) -> bool:
        """حذف قانون گروه"""
        with self._lock:
            if str(group_id) in self.rules:
                del self.rules[str(group_id)]
                self._save()
                return True
        return False
    
    def has_rule(self, group_id: str) -> bool:
        """آیا گروه قانون دارد؟"""
        return str(group_id) in self.rules