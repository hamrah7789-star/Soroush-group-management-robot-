# user_data_manager.py
"""
مدیریت لقب، اصل و جنسیت کاربران
مسیر فایل از config گرفته میشه (سازگار با همه پلتفرم‌ها)
"""

import json
import os
import tempfile
import threading
from typing import Optional, Dict, List

from config import USER_DATA_FILE


class UserDataManager:
    """مدیریت لقب، اصل و جنسیت کاربران در فایل JSON"""
    
    def __init__(self, file_path: str = None):
        self.file_path = file_path or USER_DATA_FILE
        self._lock = threading.RLock()
        self.data = self._load()
    
    def _load(self) -> Dict:
        """بارگذاری داده‌ها از فایل"""
        if not os.path.exists(self.file_path):
            return {}
        try:
            with open(self.file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
                return {}
        except json.JSONDecodeError as e:
            print(f"⚠️ JSON خراب در {self.file_path}: {e}")
            try:
                backup = self.file_path + ".corrupted"
                os.replace(self.file_path, backup)
                print(f"📦 فایل خراب به {backup} منتقل شد")
            except:
                pass
            return {}
        except Exception as e:
            print(f"❌ خطا در خواندن {self.file_path}: {e}")
            return {}
    
    def _save(self):
        """ذخیره اتمیک در فایل"""
        with self._lock:
            try:
                dir_name = os.path.dirname(self.file_path) or "."
                os.makedirs(dir_name, exist_ok=True)
                
                fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
                try:
                    with os.fdopen(fd, 'w', encoding='utf-8') as f:
                        json.dump(self.data, f, ensure_ascii=False, indent=2)
                        f.flush()
                        os.fsync(f.fileno())
                    os.replace(tmp_path, self.file_path)
                except:
                    try:
                        os.unlink(tmp_path)
                    except:
                        pass
                    raise
            except Exception as e:
                print(f"❌ خطا در ذخیره {self.file_path}: {e}")
                raise
    
    # ============================================================
    # 🔑 کلید داخلی
    # ============================================================
    
    def _key(self, user_id: str, group_id: str) -> str:
        return f"{user_id}_{group_id}"
    
    # ============================================================
    # 🏷️ لقب
    # ============================================================
    
    def set_nickname(self, user_id: str, group_id: str, nickname: str):
        with self._lock:
            key = self._key(user_id, group_id)
            if key not in self.data:
                self.data[key] = {}
            self.data[key]["nickname"] = nickname
            self._save()
    
    def get_nickname(self, user_id: str, group_id: str) -> Optional[str]:
        key = self._key(user_id, group_id)
        return self.data.get(key, {}).get("nickname")
    
    # ============================================================
    # 📍 اصل / شهر
    # ============================================================
    
    def set_origin(self, user_id: str, group_id: str, origin: str):
        with self._lock:
            key = self._key(user_id, group_id)
            if key not in self.data:
                self.data[key] = {}
            self.data[key]["origin"] = origin
            self._save()
    
    def get_origin(self, user_id: str, group_id: str) -> Optional[str]:
        key = self._key(user_id, group_id)
        return self.data.get(key, {}).get("origin")
    
    # ============================================================
    # 👤 جنسیت
    # ============================================================
    
    def set_gender(self, user_id: str, group_id: str, gender: str):
        """ثبت جنسیت کاربر (male/female)"""
        with self._lock:
            key = self._key(user_id, group_id)
            if key not in self.data:
                self.data[key] = {}
            self.data[key]["gender"] = gender
            self._save()
    
    def get_gender(self, user_id: str, group_id: str) -> Optional[str]:
        """دریافت جنسیت کاربر (male/female)"""
        key = self._key(user_id, group_id)
        return self.data.get(key, {}).get("gender")
    
    # ============================================================
    # 📦 اطلاعات کامل
    # ============================================================
    
    def get_all(self, user_id: str, group_id: str) -> Dict:
        """دریافت همه اطلاعات کاربر"""
        key = self._key(user_id, group_id)
        return self.data.get(key, {}).copy()
    
    def delete_user(self, user_id: str, group_id: str):
        """حذف اطلاعات کاربر"""
        with self._lock:
            key = self._key(user_id, group_id)
            if key in self.data:
                del self.data[key]
                self._save()
    
    # ============================================================
    # 👥 جستجو بر اساس جنسیت
    # ============================================================
    
    def get_users_by_gender(self, group_id: str, gender: str) -> List[str]:
        """دریافت لیست کاربران با جنسیت مشخص"""
        result = []
        suffix = f"_{group_id}"
        for key, value in self.data.items():
            if key.endswith(suffix) and value.get("gender") == gender:
                # با rsplit امن‌تره
                user_id = key.rsplit("_", 1)[0]
                result.append(user_id)
        return result
    
    def get_all_users_in_group(self, group_id: str) -> Dict:
        """دریافت همه کاربران یک گروه به صورت {user_id: data}"""
        result = {}
        suffix = f"_{group_id}"
        for key, value in self.data.items():
            if key.endswith(suffix):
                user_id = key.rsplit("_", 1)[0]
                result[user_id] = value
        return result