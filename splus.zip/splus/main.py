import asyncio
import time
import os
from bot import SoroushBot
from config import BASE_PATH

os.makedirs(BASE_PATH, exist_ok=True)

async def main():
    print("=" * 60)
    print("🤖 ربات مدیریت گروه سروش")
    print("=" * 60)
    print()
    print("📱 لطفاً شماره و کد را در ترمینال وارد کنید...")
    print("=" * 60)
    
    # ======== اجرای ربات ========
    bot = SoroushBot()
    
    # ======== شروع ربات ========
    await bot.start()
    
    # ======== بعد از لاگین موفق ========
    if bot.is_logged_in:
        print()
        print("=" * 60)
        print("✅ ربات با موفقیت روشن شد!")
        print(f"📱 شماره: {bot.phone}")
        print(f"🤖 آیدی ربات: {bot.bot_id}")
        print("=" * 60)
        print()
        print("💡 ربات در حال اجراست...")
        print("🛑 برای توقف: Ctrl+C")
        print("=" * 60)
    
    # نگه داشتن برنامه
    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 ربات متوقف شد")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 ربات متوقف شد")
    except Exception as e:
        print(f"❌ خطا: {e}")